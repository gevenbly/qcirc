/*
functions related to menu selections
*/

function changeSelectedType() {
  selectedType = selectedTypeElement.value;
}
